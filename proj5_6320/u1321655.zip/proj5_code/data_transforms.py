'''
Contains functions with different data transforms
'''

import numpy as np
import torchvision.transforms as transforms

from typing import Tuple


def get_fundamental_transforms(inp_size: Tuple[int, int],
                               pixel_mean: np.array,
                               pixel_std: np.array) -> transforms.Compose:
  '''
  Returns the core transforms needed to feed the images to our model

  Args:
  - inp_size: tuple denoting the dimensions for input to the model
  - pixel_mean: the mean  of the raw dataset
  - pixel_std: the standard deviation of the raw dataset
  Returns:
  - fundamental_transforms: transforms.Compose with the fundamental transforms
  '''

  fundamental_transforms = None

  #############################################################################
  # Student code begin
  #############################################################################
  # In torchvision transforms are simply operations done to input
  # We can use compose to combine these transforms to be done in a pipeline
  fundamental_transforms = transforms.Compose([
    transforms.Resize(inp_size),
    transforms.ToTensor(),
    transforms.Normalize(pixel_mean, pixel_std)
  ])

  #############################################################################
  # Student code end
  #############################################################################
  return fundamental_transforms


def get_data_augmentation_transforms(inp_size: Tuple[int, int],
                                     pixel_mean: np.array,
                                     pixel_std: np.array) -> transforms.Compose:
  '''
  Returns the data augmentation + core transforms needed to be applied on the
  train set

  Args:
  - inp_size: tuple denoting the dimensions for input to the model
  - pixel_mean: the mean  of the raw dataset
  - pixel_std: the standard deviation of the raw dataset
  Returns:
  - aug_transforms: transforms.Compose with all the transforms
  '''

  aug_transforms = None

  #############################################################################
  # Student code begin
  #############################################################################

  aug_transforms = transforms.Compose([
    transforms.RandomResizedCrop(
      size=inp_size, 
      scale=(0.8, 1.0)
    ),
    transforms.RandomHorizontalFlip(p=0.5),  # Best augmentation
    transforms.RandomRotation(12),           # Small rotation
    transforms.ColorJitter(
        brightness=0.20, 
        contrast=0.20
    ),                                       # Very small jitter (safe)
    transforms.ToTensor(),
    transforms.Normalize(pixel_mean, pixel_std),
  ])

  #############################################################################
  # Student code end
  #############################################################################
  return aug_transforms
